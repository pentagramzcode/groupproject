<?php
require 'includes/db.php';
include 'includes/header.php';

// Get 6 featured listings from database
$stmt = $pdo->query("SELECT * FROM items WHERE status = 'active' ORDER BY created_at DESC LIMIT 6");
$featuredItems = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Student Marketplace - Brighton</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <main>
    <section class="hero">
      <h2>Welcome to the Marketplace</h2>
      <p>Buy and sell items locally in Brighton</p>
    </section>

    <section class="featured-items">
      <h2>Featured Items</h2>
      <div class="items-list">
        <?php if (empty($featuredItems)): ?>
          <p class="no-items">No featured items available yet.</p>
        <?php else: ?>
          <?php foreach ($featuredItems as $item): ?>
            <div class="item-card">
              <a href="item-details.php?id=<?= htmlspecialchars($item['id'] ?? '') ?>">
                <div class="item-image">
                  <img src="<?= htmlspecialchars($item['image_url'] ?? 'images/placeholder.jpg') ?>" alt="<?= htmlspecialchars($item['title'] ?? 'Untitled Item') ?>">
                </div>
                <div class="item-info">
                  <h3><?= htmlspecialchars($item['title'] ?? 'Untitled Item') ?></h3>
                  <p class="price">£<?= isset($item['price']) ? number_format($item['price'], 2) : 'N/A' ?></p>
                  <p class="location"><?= htmlspecialchars($item['location'] ?? 'Unknown Location') ?></p>
                </div>
              </a>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </section>
  </main>

  <?php
  // Only include footer if it exists
  if (file_exists('includes/footer.php')) {
    include 'includes/footer.php';
  } else {
    echo '<footer><p>&copy; 2025 Student Marketplace. All rights reserved.</p></footer>';
  }
  ?>
</body>

</html>
